const fs = require('fs');

let base = 5;
let table = '';
for(let i = 1; i <= 10; i++){
    let tabla = `${i}.-${base} x ${i} = ${base * i}`;
    table = `${table}\n${tabla}`;
    fs.writeFile(`EjemploTabla${base}.txt`, `${table}`, (error) => {
        if(error) throw error;
        console.log('el archivo ejemplo.txt ha sido creado con exito');
    });}

